# Problem Set 2, hangman.py
# Name: 
# Collaborators:
# Time spent:

# Hangman Game
# -----------------------------------
# Helper code
# You don't need to understand this helper code,
# but you will have to know how to use the functions
# (so be sure to read the docstrings!)
import random
import string

WORDLIST_FILENAME = "words.txt"


def load_words():
    """
    Returns a list of valid words. Words are strings of lowercase letters.
    
    Depending on the size of the word list, this function may
    take a while to finish.
    """
    print("Loading word list from file...")
    # inFile: file
    inFile = open(WORDLIST_FILENAME, 'r')
    # line: string
    line = inFile.readline()
    # wordlist: list of strings
    wordlist = line.split()
    print("  ", len(wordlist), "words loaded.")
    return wordlist


def choose_word(wordlist):
    """
    wordlist (list): list of words (strings)

    Returns a word from wordlist at random
    """
    return random.choice(wordlist)


# end of helper code

# -----------------------------------

# Load the list of words into the variable wordlist
# so that it can be accessed from anywhere in the program

wordlist = load_words()


def is_word_guessed(secret_word, letters_guessed):
    """
    If word is guessed function returns true
    """
    if set(secret_word) & set(letters_guessed) == set(secret_word):
        return True
    else:
        return False


def get_guessed_word(secret_word, letters_guessed):
    """
    This function returns string with guessed letters
    """

    true_letters_guessed = set(secret_word) & set(letters_guessed)
    output = ''

    for i in range(len(secret_word)):
        if secret_word[i] in true_letters_guessed:
            output += secret_word[i] + ' '
        else:
            output += '_ '

    return output


def get_available_letters(letters_guessed):
    '''
    This function returns available letters
    '''

    answer_set = sorted(set(string.ascii_lowercase) - set(letters_guessed.lower()))
    answer_str = ''.join(answer_set)

    return answer_str


def check_input(guesses, warnings):
    '''
    This function checks what user inputs in command line
    '''
    while True:
        letter = input('Please input letter: ')
        if letter.isalpha() and len(letter) == 1:
            break
        elif len(letter) > 1:
            if warnings < 1:
                guesses -= 1
                print('Only one letter. You have', guesses, 'guesses left')
            elif warnings > 0:
                warnings -= 1
                print('Only one letter. You have', warnings, 'warnings left')
        else:
            if warnings < 1:
                guesses -= 1
                print('Use only letters. You have', guesses, 'guesses left')
            elif warnings > 0:
                warnings -= 1
                print('Only one letter. You have', warnings, 'warnings left')



    return letter, guesses, warnings


def check_input_hints(guesses, warnings, guessed_word):
    '''
    This function checks what user inputs in command line
    and give information to hangman_with_hints function
    '''
    while True:
        letter = input('Please input letter: ')
        if letter.isalpha() and len(letter) == 1:
            break
        elif letter == '*':
            print(show_possible_matches(str(guessed_word)))
            break
        elif len(letter) > 1:
            if warnings < 1:
                guesses -= 1
                print('Only one letter. You have', guesses, 'guesses left')
            elif warnings > 0:
                warnings -= 1
                print('Only one letter. You have', warnings, 'warnings left')
        else:
            if warnings < 1:
                guesses -= 1
                print('Use only letters. You have', guesses, 'guesses left')
            elif warnings > 0:
                warnings -= 1
                print('Only one letter. You have', warnings, 'warnings left')
    return letter


def hangman(secret_word):
    '''
    This is a Hangman function which operates others functions
    '''
    print('Welcome to the game Hangman!', '\nI am thinking of a word that is', len(secret_word), 'letters long.')

    print('_ ' * len(secret_word))
    guessed = ''
    guess_remaining = 6
    warnings_remaining = 3

    while guess_remaining > 0:
        print('Available letters:', get_available_letters(guessed))
        print('You have', guess_remaining, 'guesses left.')

        letter = check_input(guess_remaining, warnings_remaining)
        guessed += letter[0].lower()
        guess_remaining = letter[1]
        warnings_remaining = letter[2]
        print(get_guessed_word(secret_word, guessed))

        if is_word_guessed(secret_word, guessed) == True:
            print('Congratulations, you won!')
            print('Total score is: ', (guess_remaining) * len(set(secret_word)))
            break

        elif letter == '*':
            pass
        else:
            if set(letter) & set(secret_word):
                print('Good guess')
            else:
                print('Oops! That letter is not in my word')
                guess_remaining -= 1
        if guess_remaining == 0 and is_word_guessed(secret_word, guessed) == False:
            print('You lost')
            break


# When you've completed your hangman function, scroll down to the bottom
# of the file and uncomment the first two lines to test
# (hint: you might want to pick your own
# secret_word while you're doing your own testing)


# -----------------------------------


def match_with_gaps(my_word, other_word):
    '''
    This function returns true in case letters
    of guessed word match with gaps of given word
    '''
    my_word = my_word.replace(' ', '')
    my_word_clone = ''

    if len(my_word) == len(other_word):
        for i in range(len(my_word)):
            if my_word[i] not in string.ascii_letters:
                my_word_clone += '_'
            else:
                my_word_clone += other_word[i]

    if my_word == my_word_clone:
        return True
    else:
        return False


def show_possible_matches(my_word):
    '''
    This function returns all possible matches
    '''
    output = ''
    for i in range(len(wordlist)):
        if match_with_gaps(my_word, wordlist[i]):
            output += wordlist[i] + ' '
        else:
            pass

    return output


def hangman_with_hints(secret_word):
    '''
    Hangman function with hints
    '''
    print('Welcome to the game Hangman!', '\nI am thinking of a word that is', len(secret_word), 'letters long.')
    print('_ ' * len(secret_word))
    guessed = ''
    guess_remaining = 6
    warnings_remaining = 3

    while guess_remaining > 0:
        print('Available letters:', get_available_letters(guessed))
        print('You have', guess_remaining, 'guesses left.')

        letter = check_input_hints(guess_remaining, warnings_remaining)
        guessed += letter[0].lower()
        guess_remaining = letter[1]
        warnings_remaining = letter[2]

        print(get_guessed_word(secret_word, guessed))

        if is_word_guessed(secret_word, guessed) == True:
            print('Congratulations, you won!')
            print('Total score is: ', (guess_remaining) * len(set(secret_word)))
            break

        elif letter == '*':
            pass
        else:
            if set(letter) & set(secret_word):
                print('Good guess')
            else:
                print('Oops! That letter is not in my word')
                guess_remaining -= 1
        if guess_remaining == 0 and is_word_guessed(secret_word, guessed) == False:
            print('You lost')
            break


# When you've completed your hangman_with_hint function, comment the two similar
# lines above that were used to run the hangman function, and then uncomment
# these two lines and run this file to test!
# Hint: You might want to pick your own secret_word while you're testing.

secret_word = choose_word(wordlist)
hangman(secret_word)  # Input args to hangman

if __name__ == "__main__":
    pass
    # To test part 2, comment out the pass line above and
    # uncomment the following two lines.

    # secret_word = choose_word(wordlist)
    # hangman_with_hints(secret_word)

###############
